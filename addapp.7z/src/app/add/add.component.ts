import { Component, OnInit } from '@angular/core';
import {FormGroup,Validators,FormControl} from '@angular/forms';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor() { }
   Id:number;
   name:string;
   des:string;
   price:number;



  ngOnInit():void {
  
 
}

checkPrice(){
  if(this.price>0) {console.log("true");return true;}
  return false;
}

}